package com.cristian.example.bicycles.entity.dao;

import org.springframework.data.repository.CrudRepository;

import com.cristian.example.bicycles.entity.models.Bicycle;

public interface IBicycleDao extends CrudRepository <Bicycle,Long>{

}
